# Scene photography

## public/images/tom-avatar.png

Generated with the built-in image_gen tool; retained unchanged across all profile states.

Use case: photorealistic-natural. Create a square photographic profile portrait of Tom, a fictional 22-year-old university student for The Better Me interactive fiction. Head and shoulders, looking toward camera, ordinary approachable young adult man with short slightly wavy dark brown hair, clean shaven, natural skin texture, soft neutral expression with a very slight smile, muted sage green plain cotton crewneck shirt. Soft warm daylight, simple pale sage / warm ivory studio-like wall background, understated editorial photography with gentle film texture. Centered symmetrical composition with generous breathing room around head, suitable for circular avatar crop; entire hair and shoulders within image. Warm, believable, everyday person, not glamour or fashion photography, no beauty retouching, no dramatic mood, no text, no logos, no watermark. Single person, single photograph.

Generated with the built-in image_gen tool. These are fictional photographic illustrations, not documentary images. The same image accompanies each scene before and after optimization.

## public/images/message.png

Use case: photorealistic-natural. Create a single landscape editorial photograph for the interactive fiction The Better Me, scene about overthinking messages. Close candid over-the-shoulder view of a 22-year-old man in a muted sage cotton shirt at a small wooden desk by an apartment window, holding a phone, thumb hovering thoughtfully above a softly blurred messaging screen. Face outside the frame. A half-full ceramic cup, quiet evening daylight. Warm ivory, dusty sage, natural wood, subdued film grain, authentic ordinary life, gentle contrast, refined cinematic photography. Horizontal 3:2 composition, primary phone and hands in central area suitable for wide website crop. No legible text, logos, watermarks, collages, UI overlays. Neutral emotional tone, no exaggerated sadness, no glamour.

## public/images/memories.png

Use case: photorealistic-natural. Create a single landscape editorial still-life photograph for the interactive fiction The Better Me, scene about attachment to the past. An open small shoebox of worn birthday greeting cards and envelopes on an ordinary young adult's bedroom wooden desk; an old slightly faded snapshot lying on top shows three young adult basketball teammates with arms around one another on an outdoor court after a game, one in a sage shirt. A softly out-of-focus worn basketball sits beside the desk in background. The photograph in the scene must look like a natural printed memory, no readable card text. Soft afternoon window light, warm ivory, dusty sage, gentle olive shadows, muted film grain, realistic paper textures, quiet tender and ambiguous mood. Horizontal 3:2 photo, central objects suitable for wide website crop. No logos, watermark, words, collages, interface, excessive props.

## public/images/friends.png

Use case: photorealistic-natural. Create a single landscape candid editorial photograph for the interactive fiction The Better Me, scene about hesitation and group decisions. Three ordinary university-age adult friends at a small cafe table planning an outing. Main person in muted sage cotton shirt seen from behind at left, leaning toward a simple folded paper map on table; across the table two friends listening, one friend gently lifting a hand mid-explanation. Natural subtle body language, nobody angry or triumphant. Focus on their hands and shared table, faces secondary, no hero posing. Ivory cafe walls, soft window daylight, warm wood, dusty sage and cream clothing, authentic film photography, restrained contrast and grain matching a quiet personal-growth product. Horizontal 3:2 composition, key interaction centrally framed for a wide website crop. No readable text, logos, watermark, collages or interface.

