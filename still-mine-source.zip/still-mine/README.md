# Still Mine?

An English interactive fiction for the course question **What Does It Mean to Be Human in the Age of AI?** The player is Tom’s AI assistant. The story asks who shapes a life when expression, self-understanding and decisions become shared work with AI.

## Run

Node.js 22.6+ (24 recommended) and npm.

```sh
npm install
npm run dev -- --port 5174 --strictPort
```

Open the printed local address. Initial dependency installation needs internet; the experience runs locally without network calls after that.

```sh
npm test
npm run build
npm run preview
```

`dist/` is the production-ready static site. No public deployment was made. The earlier personality-detox version is preserved separately in `../detoxication-before-delegation.zip`.

## Narrative

Tom wants to attend a reunion with his former basketball teammates. He gives limited permission for the AI to help with this reunion and says he wants to discuss the arrangement afterward. Three requests unfold in chronological order:

1. **Speak for me:** respond to Maya’s invitation.
2. **Help me understand myself:** interpret his notes about a missed shot and his teammates’ support.
3. **Choose for me:** arrange the reunion using the group’s stated constraints.

Each request offers three equally presented actions: suggest and let Tom decide, prepare a draft for approval, or act within his permission. Every action has distinct dialogue, a practical benefit, a remaining difficulty and a saved trace. The AI’s interpretation, criterion for usefulness and missing context are visible. There are 27 assistance paths, not just different button orders. No path is declared a diagnosis or an objective identity verdict.

After the reunion, Tom requests his own future boundaries. The player proposes a new arrangement. Tom’s request follows the assistance he experienced. He may ask to review a sent message next time, keep editing interpretations, or delegate more planning after tiring of coordinating a shortlist. He accepts compatible offers and counters incompatible ones. The stored proposal and agreed arrangement are separate. Past events are not rewritten when future boundaries change.

After one or two tasks, Pause Here opens a partial reflection and Continue the Story resumes the next request. Full paths reach a before/after account, exact delegation history, and the proposed/agreed boundaries. Start Again clears narrative records, proposals, agreement and reflection.

## Containers and visual presentation

The green jars preserve drafts, meanings and options left outside the selected answer. They do not contain literal personality or delete memories. Each explored jar opens its own trace, benefit and remaining tension. Empty jars are disabled. Keyboard activation, dialog naming, Escape and focus return are supported by native controls.

The green product design and dripping title remain. Images are bundled locally and visible in the message, photograph and planning scenes. Users preview role-specific drafts or plans before confirming an action. Background music, audio controls, the audio engine and fracture overlays have been removed. A single small shake still follows an automatically handled task; reduced-motion mode disables it. There are no external audio requests or Web Audio contexts.

## Source

- `src/model.ts`: episodes, all nine mode-specific outcomes, guarded state machine, history, derived profile, conditional ending, Tom’s boundary negotiation.
- `src/main.tsx`: narrative screens, mode preview/confirmation, saved-trace dialogs and future-arrangement form.
- `src/scenes.tsx`: visible message, memory-photo and planning objects, plus mode-specific previews.
- `src/scenes.css`: object layouts, preview states and reaction presentation.
- `src/style.css`: original visual foundations.
- `src/green-theme.css`: green palette.
- `src/delegation.css`: layout and interaction presentation for this trial.
- `src/model.test.ts`: 27 assistance paths, 27 boundary proposals per path, early pause/resume, duplicate actions, reset.
- `public/images/`: generated fictional photographic illustrations; prompts in `IMAGE-PROMPTS.md`.

The application uses React, TypeScript and Vite. The photos are fictional AI-generated illustrations. All responses and negotiations are prewritten; there is no live AI model, account, database, analytics or external asset request. Reflection stays only in browser memory and is lost after reload, closing the page or restart.

## Verification and limits

32 automated tests passed, including 27 complete assistance paths and all 729 combinations of historical path and future proposal. TypeScript and production build passed. Browser checks cover contrasting assistance paths, archive keyboard use, early pause/resume, Tom countering automatic-action proposals, accepted boundaries, reflection/reset and responsive widths. No physical-device, Safari or full screen-reader audit has been performed. The main scene flow uses explicit navigation rather than browser history.

## Reading pass

The default request view foregrounds the messages, Tom’s request and three concise choices. AI interpretation, usefulness criteria and missing context are available through Review your AI interpretation. Result screens show Tom’s response first; the action taken, benefit and remaining difficulty are grouped in the collapsed Review this choice panel. Images remain optional, and repeated explanatory narration is shortened. Dialogue, complete branch content, collection records and future-boundary choices are preserved.


## Scene and response pass

A role selection now previews the proposed action and does not commit it. A separate, specifically labeled button authorizes sending, asking, interpreting or booking. Switching previews changes no story record. The memory photograph can be inspected with a keyboard-accessible toggle. Each result includes a visible action by Tom as well as his dialogue. Future requests derive from the actual assistance mode for that task, including requests for more help. Boundary summaries spell out who writes, reviews, sends and books rather than showing only abstract status labels. The earlier reading reduction is retained for analytical explanations.

## Visual edit illustration

The memory-review result now shows a locally rendered phone conversation instead of narrating the correction: Tom crosses out “achievement,” circles “belonging,” and saves “This memory is about belonging, not performance.” The HTML/SVG illustration keeps text selectable and adapts to mobile. Drawing and appearance animations become static in reduced-motion mode. Other assistance branches retain their distinct reactions.


The post-reunion “Whose words were they?” dialogue has been removed. The evening transition now opens Tom’s concrete future-boundary requests directly.

## Compact visual story pass

The UI now moves straight from one request to the next; the repeated chapter menu is no longer a visible screen. The full profile is opened from a small Tom control, beside the clickable trace jars. Each request combines a visible photograph and a message/memory/booking object with three role tabs and a single confirmation action. Memory photographs truly turn between front and back. All nine task/mode outcomes now have visual representations: sent-message bubbles, approvals, Tom’s added line, handwritten notes, the editable memory phone illustration, a kept card, and booking/shortlist states. Tom’s edit can be replayed. Detailed reactions, context and consequences remain in the trace dialogs.

Future-boundary requests appear one at a time, with Back/Next controls. The agreement shows one adopted boundary per task and strikes out an offer only when Tom changes it. The final review is a gallery rather than repeated full profile cards; complete records remain expandable. No audio or fracture overlays are present.

Browser verification covered all nine result variants across three full paths, preview without committing, photograph keyboard toggle, trace-dialog keyboard access, pause/resume, the three-step boundary proposal, counteroffers, saved reflection, reset and widths 320/390/768/1440. Sample default request text was 54–63 English words and result text 40–52 words (main scene only; expandable records excluded). The older UI is backed up as `../detoxication-before-compact-story.zip`.

New UI source: `src/objects.tsx`, `src/visual-copy.ts`, and `src/compact-story.css`. The state model and complete narrative outcomes are preserved.


The current title is **Still Mine?**, reflecting the question of ownership and agency in AI-assisted expression, interpretation and decisions. Historical backup filenames retain their original names.


### Daylight palette
The current interface uses paper white, apricot, terracotta and charcoal across the cover, workspaces, outcomes, records and dialogs. The final override is in `src/daylight-theme.css`. Chrome checks covered the cover, request, outcome and archive dialog, reduced motion, and overflow at 320, 390, 768 and 1440 pixels. Production build passed.
